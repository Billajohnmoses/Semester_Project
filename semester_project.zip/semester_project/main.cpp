#include<iostream>
#include<cstdlib>
#include<ctime>

#define rock 1
#define paper 2
#define scissors 3
//rock breaks scissors
//scissors cuts paper
//paper covers rock 
using namespace std;

int main()
{
srand((unsigned int) time(0));
int player_throw;
int computer_throw;
bool draw = false;
do {
     cout <<"select your throw"<<endl;
    cout << "1] rock"<<endl;
    cout <<"2] paper"<<endl;
    cout <<"3] scissors"<<endl;
    cout <<"Enter your selection"<<endl;
    cin >> player_throw;
    cout <<endl;
    
    computer_throw = (rand()%3)+1;
    if(computer_throw == rock){
    cout <<"computer throws rock "<<endl;
    }
    else if(computer_throw == paper){
    cout <<"computer throws paper"<<endl;
    }
    else if (computer_throw == scissors){
    cout <<"computer throws scissors"<<endl;
    }
    draw = false;
    
    if (player_throw == computer_throw){
    draw = true;
    cout <<"Draw! play again!"<<endl;
    }
    else if (player_throw == rock && computer_throw ==scissors){
    cout <<"rock breaks scissors! you win!." <<endl;
    }
    else if (player_throw == rock && computer_throw == paper){
    cout <<"paper covers rock! you lose!."<<endl;
    }
    else if(player_throw == paper && computer_throw == rock){
    cout<<"paper covers rock! you win!."<<endl;
    }
    else if (player_throw == paper && computer_throw == scissors){
    cout <<"scissors cuts paper! you lose!."<<endl;
    }
    else if (player_throw == scissors && computer_throw == paper){
    cout <<"scissors cuts paper! you win!."<<endl;
    }
    else if (player_throw == scissors && computer_throw == rock){
    cout <<"rock breaks scissors! you lose!."<<endl;
    }
    cout <<endl;
}
while (draw);
   
    return 0;
}
